"""Widgets package initialization."""
