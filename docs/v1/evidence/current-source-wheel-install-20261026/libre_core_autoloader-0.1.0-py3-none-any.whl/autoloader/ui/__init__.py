"""UI package initialization."""
